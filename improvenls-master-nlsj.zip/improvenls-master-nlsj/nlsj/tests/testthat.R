library(testthat)
library(nlsj)

test_check("nlsj")
