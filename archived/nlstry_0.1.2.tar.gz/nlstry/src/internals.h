#ifndef INTERNALS_H
#define INTERNALS_H

#include <Rinternals.h>

SEXP R_NewEnv(SEXP, int, int);

#endif
