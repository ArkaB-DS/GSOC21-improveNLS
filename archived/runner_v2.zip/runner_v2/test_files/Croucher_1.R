#  Croucher001.R
NLSstart <- c(p1=1, p2=0.2)